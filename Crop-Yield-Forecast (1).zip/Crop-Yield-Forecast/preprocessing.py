import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
import joblib
import os

class DataPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoder = LabelEncoder()
        self.is_fitted = False
        
    def fit(self, df, feature_columns, crop_column='crop_type'):
        features = df[feature_columns].values
        self.scaler.fit(features)
        
        if crop_column in df.columns:
            self.label_encoder.fit(df[crop_column])
        
        self.is_fitted = True
        return self
    
    def transform(self, df, feature_columns, crop_column='crop_type'):
        if not self.is_fitted:
            raise ValueError("Preprocessor must be fitted before transform")
        
        features = df[feature_columns].values
        scaled_features = self.scaler.transform(features)
        
        if crop_column in df.columns:
            encoded_crop = self.label_encoder.transform(df[crop_column])
            result = np.column_stack([encoded_crop, scaled_features])
        else:
            result = scaled_features
            
        return result
    
    def fit_transform(self, df, feature_columns, crop_column='crop_type'):
        self.fit(df, feature_columns, crop_column)
        return self.transform(df, feature_columns, crop_column)
    
    def transform_single(self, crop_type, features_dict, feature_columns):
        if not self.is_fitted:
            raise ValueError("Preprocessor must be fitted before transform")
        
        feature_values = np.array([[features_dict[col] for col in feature_columns]])
        scaled_features = self.scaler.transform(feature_values)
        
        encoded_crop = self.label_encoder.transform([crop_type])
        
        result = np.column_stack([encoded_crop, scaled_features])
        return result
    
    def save(self, filepath='model/preprocessor.pkl'):
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        joblib.dump({
            'scaler': self.scaler,
            'label_encoder': self.label_encoder,
            'is_fitted': self.is_fitted
        }, filepath)
        
    def load(self, filepath='model/preprocessor.pkl'):
        data = joblib.load(filepath)
        self.scaler = data['scaler']
        self.label_encoder = data['label_encoder']
        self.is_fitted = data['is_fitted']
        return self

def clean_data(df):
    df = df.dropna()
    
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        Q1 = df[col].quantile(0.01)
        Q3 = df[col].quantile(0.99)
        df = df[(df[col] >= Q1) & (df[col] <= Q3)]
    
    return df
