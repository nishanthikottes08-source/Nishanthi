import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import joblib

from utils.data_loader import load_dataset, get_feature_columns
from preprocessing import DataPreprocessor, clean_data

def train_model():
    print("Loading dataset...")
    df = load_dataset()
    
    print("Cleaning data...")
    df = clean_data(df)
    
    feature_columns = get_feature_columns()
    
    print("Preprocessing data...")
    preprocessor = DataPreprocessor()
    X = preprocessor.fit_transform(df, feature_columns)
    y = df['yield_per_hectare'].values
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print("Training Random Forest model...")
    model = RandomForestRegressor(
        n_estimators=100,
        max_depth=15,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )
    
    model.fit(X_train, y_train)
    
    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    
    print(f"\nModel Performance:")
    print(f"RMSE: {rmse:.4f}")
    print(f"MAE: {mae:.4f}")
    print(f"R² Score: {r2:.4f}")
    
    os.makedirs('model', exist_ok=True)
    
    print("\nSaving model...")
    joblib.dump(model, 'model/crop_yield_model.pkl')
    
    print("Saving preprocessor...")
    preprocessor.save('model/preprocessor.pkl')
    
    print("\nGenerating feature importance plot...")
    feature_names = ['crop_type'] + feature_columns
    importance = model.feature_importances_
    
    indices = np.argsort(importance)[::-1]
    
    plt.figure(figsize=(12, 6))
    plt.title('Feature Importance for Crop Yield Prediction')
    plt.bar(range(len(importance)), importance[indices], align='center')
    plt.xticks(range(len(importance)), [feature_names[i] for i in indices], rotation=45, ha='right')
    plt.xlabel('Features')
    plt.ylabel('Importance')
    plt.tight_layout()
    
    os.makedirs('static', exist_ok=True)
    plt.savefig('static/feature_importance.png', dpi=100, bbox_inches='tight')
    plt.close()
    
    print("Training complete!")
    
    return model, preprocessor

if __name__ == '__main__':
    train_model()
