import joblib
import numpy as np
from preprocessing import DataPreprocessor
from utils.data_loader import get_feature_columns

class CropYieldPredictor:
    def __init__(self, model_path='model/crop_yield_model.pkl', 
                 preprocessor_path='model/preprocessor.pkl'):
        self.model = None
        self.preprocessor = None
        self.model_path = model_path
        self.preprocessor_path = preprocessor_path
        self.is_loaded = False
        
    def load(self):
        try:
            self.model = joblib.load(self.model_path)
            self.preprocessor = DataPreprocessor()
            self.preprocessor.load(self.preprocessor_path)
            self.is_loaded = True
            return True
        except FileNotFoundError as e:
            print(f"Model files not found: {e}")
            return False
    
    def predict(self, crop_type, features_dict):
        if not self.is_loaded:
            if not self.load():
                raise ValueError("Failed to load model and preprocessor")
        
        feature_columns = get_feature_columns()
        
        X = self.preprocessor.transform_single(crop_type, features_dict, feature_columns)
        
        prediction = self.model.predict(X)[0]
        
        return round(max(prediction, 0), 2)
    
    def get_feature_importance(self):
        if not self.is_loaded:
            if not self.load():
                raise ValueError("Failed to load model")
        
        feature_columns = get_feature_columns()
        feature_names = ['crop_type'] + feature_columns
        importance = self.model.feature_importances_
        
        return dict(zip(feature_names, importance))

def predict_yield(crop_type, soil_ph, nitrogen, phosphorus, potassium, 
                  organic_carbon, soil_moisture, temperature, rainfall,
                  humidity, solar_radiation, wind_speed):
    
    predictor = CropYieldPredictor()
    
    features = {
        'soil_ph': soil_ph,
        'nitrogen': nitrogen,
        'phosphorus': phosphorus,
        'potassium': potassium,
        'organic_carbon': organic_carbon,
        'soil_moisture': soil_moisture,
        'temperature': temperature,
        'rainfall': rainfall,
        'humidity': humidity,
        'solar_radiation': solar_radiation,
        'wind_speed': wind_speed
    }
    
    return predictor.predict(crop_type, features)
