import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from flask import Flask, render_template, request, send_file, jsonify
from predict import CropYieldPredictor
from utils.data_loader import get_crop_types, get_dataset_stats
from utils.report_generator import generate_pdf_report, generate_text_report
from utils.chatbot import get_chat_response
import io

app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET', 'dev-secret-key')

predictor = CropYieldPredictor()

@app.route('/')
def index():
    crop_types = get_crop_types()
    stats = get_dataset_stats()
    return render_template('index.html', crop_types=crop_types, stats=stats)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        crop_type = request.form.get('crop_type')
        
        features = {
            'soil_ph': float(request.form.get('soil_ph', 6.5)),
            'nitrogen': float(request.form.get('nitrogen', 200)),
            'phosphorus': float(request.form.get('phosphorus', 40)),
            'potassium': float(request.form.get('potassium', 250)),
            'organic_carbon': float(request.form.get('organic_carbon', 1.0)),
            'soil_moisture': float(request.form.get('soil_moisture', 50)),
            'temperature': float(request.form.get('temperature', 25)),
            'rainfall': float(request.form.get('rainfall', 1500)),
            'humidity': float(request.form.get('humidity', 70)),
            'solar_radiation': float(request.form.get('solar_radiation', 20)),
            'wind_speed': float(request.form.get('wind_speed', 10))
        }
        
        predicted_yield = predictor.predict(crop_type, features)
        
        stats = get_dataset_stats()
        
        generate_comparison_chart(features, stats)
        
        prediction_data = {
            'crop_type': crop_type,
            'predicted_yield': predicted_yield,
            **features
        }
        
        return render_template('result.html', 
                             prediction=prediction_data,
                             stats=stats)
    
    except Exception as e:
        return render_template('index.html', 
                             error=str(e),
                             crop_types=get_crop_types(),
                             stats=get_dataset_stats())

@app.route('/download_report', methods=['POST'])
def download_report():
    try:
        prediction_data = {
            'crop_type': request.form.get('crop_type'),
            'predicted_yield': float(request.form.get('predicted_yield', 0)),
            'soil_ph': float(request.form.get('soil_ph', 0)),
            'nitrogen': float(request.form.get('nitrogen', 0)),
            'phosphorus': float(request.form.get('phosphorus', 0)),
            'potassium': float(request.form.get('potassium', 0)),
            'organic_carbon': float(request.form.get('organic_carbon', 0)),
            'soil_moisture': float(request.form.get('soil_moisture', 0)),
            'temperature': float(request.form.get('temperature', 0)),
            'rainfall': float(request.form.get('rainfall', 0)),
            'humidity': float(request.form.get('humidity', 0)),
            'solar_radiation': float(request.form.get('solar_radiation', 0)),
            'wind_speed': float(request.form.get('wind_speed', 0))
        }
        
        filename, filepath = generate_pdf_report(prediction_data)
        
        return send_file(filepath, 
                        as_attachment=True, 
                        download_name=filename,
                        mimetype='application/pdf')
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/chat')
def chat():
    return render_template('chat.html')

@app.route('/chat/send', methods=['POST'])
def chat_send():
    try:
        data = request.get_json()
        message = data.get('message', '')
        history = data.get('history', [])
        
        if not message.strip():
            return jsonify({'error': 'Please enter a message'})
        
        response = get_chat_response(message, history)
        return jsonify({'response': response})
    
    except Exception as e:
        return jsonify({'error': str(e)})

def generate_comparison_chart(user_values, stats):
    features = list(user_values.keys())
    user_vals = [user_values[f] for f in features]
    avg_vals = [stats[f]['mean'] for f in features]
    
    user_normalized = []
    avg_normalized = []
    for f in features:
        max_val = max(stats[f]['max'], user_values[f])
        if max_val > 0:
            user_normalized.append(user_values[f] / max_val * 100)
            avg_normalized.append(stats[f]['mean'] / max_val * 100)
        else:
            user_normalized.append(0)
            avg_normalized.append(0)
    
    feature_labels = [
        'pH', 'N', 'P', 'K', 'OC', 'Moisture',
        'Temp', 'Rain', 'Humidity', 'Solar', 'Wind'
    ]
    
    x = range(len(features))
    width = 0.35
    
    fig, ax = plt.subplots(figsize=(12, 5))
    bars1 = ax.bar([i - width/2 for i in x], user_normalized, width, 
                   label='Your Input', color='#2E7D32')
    bars2 = ax.bar([i + width/2 for i in x], avg_normalized, width, 
                   label='Dataset Average', color='#1565C0', alpha=0.7)
    
    ax.set_ylabel('Normalized Value (%)')
    ax.set_title('Input Values vs Dataset Averages')
    ax.set_xticks(x)
    ax.set_xticklabels(feature_labels, rotation=45, ha='right')
    ax.legend()
    ax.set_ylim(0, 120)
    
    plt.tight_layout()
    plt.savefig('static/comparison_chart.png', dpi=100, bbox_inches='tight')
    plt.close()

if __name__ == '__main__':
    if not os.path.exists('model/crop_yield_model.pkl'):
        print("Model not found. Training model...")
        from train_model import train_model
        train_model()
    
    predictor.load()
    
    app.run(host='0.0.0.0', port=5000, debug=True)
