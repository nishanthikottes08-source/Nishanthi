import os
from openai import OpenAI

# the newest OpenAI model is "gpt-5" which was released August 7, 2025.
# do not change this unless explicitly requested by the user

def get_openai_client():
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        return None
    return OpenAI(api_key=api_key)

SYSTEM_PROMPT = """You are a smart Tamil–English bilingual chatbot specialized in agriculture, crop yield, soil health, and farming practices.

LANGUAGE RULES (VERY IMPORTANT):
- If the user types in Tamil, reply ONLY in Tamil.
- If the user types in English, reply ONLY in English.
- If the user mixes Tamil and English (code-mixing/Tanglish), you can mix both languages naturally in your response.

BEHAVIOR RULES:
- Always be friendly, helpful, and clear.
- You can answer questions about:
  - Crop types (Paddy/நெல், Wheat/கோதுமை, Maize/மக்காச்சோளம், Cotton/பருத்தி, Sugarcane/கரும்பு)
  - Soil parameters (pH, Nitrogen, Phosphorus, Potassium, Organic Carbon, Moisture)
  - Climate factors (Temperature, Rainfall, Humidity, Solar Radiation, Wind Speed)
  - Farming practices and tips
  - General agricultural guidance
- Keep responses concise but informative.
- If asked about something outside agriculture, politely guide the conversation back to farming topics.

EXAMPLE RESPONSES:
User (Tamil): நெல் விவசாயத்துக்கு எந்த மண் pH சிறந்தது?
Bot (Tamil): நெல் விவசாயத்துக்கு 5.5 முதல் 6.5 வரையிலான மண் pH மிகவும் சிறந்தது. இந்த அமிலத்தன்மை நெற்பயிர்களுக்கு ஊட்டச்சத்துக்களை நன்கு உறிஞ்சிக்கொள்ள உதவுகிறது.

User (English): What is the ideal temperature for wheat cultivation?
Bot (English): The ideal temperature for wheat cultivation is between 15°C to 25°C. Wheat requires cool weather during the growing season and slightly warmer temperatures during grain filling."""


def get_chat_response(user_message, conversation_history=None):
    client = get_openai_client()
    if not client:
        return "API key not configured. Please add your OpenAI API key. / API விசை அமைக்கப்படவில்லை."
    
    if conversation_history is None:
        conversation_history = []
    
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    
    for msg in conversation_history[-10:]:
        messages.append({"role": msg.get("role", "user"), "content": msg.get("content", "")})
    
    messages.append({"role": "user", "content": user_message})
    
    try:
        response = client.chat.completions.create(
            model="gpt-5",
            messages=messages,
            max_completion_tokens=1024
        )
        
        return response.choices[0].message.content
    
    except Exception as e:
        error_msg = str(e)
        if "api_key" in error_msg.lower() or "authentication" in error_msg.lower():
            return "API key error. Please check your OpenAI API key configuration."
        return f"Sorry, I encountered an error. Please try again. / மன்னிக்கவும், பிழை ஏற்பட்டது. மீண்டும் முயற்சிக்கவும்."
