import os
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.enums import TA_CENTER, TA_LEFT

def generate_pdf_report(prediction_data, output_path='static/reports'):
    os.makedirs(output_path, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'crop_yield_report_{timestamp}.pdf'
    filepath = os.path.join(output_path, filename)
    
    doc = SimpleDocTemplate(filepath, pagesize=letter,
                           rightMargin=72, leftMargin=72,
                           topMargin=72, bottomMargin=72)
    
    styles = getSampleStyleSheet()
    
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        spaceAfter=30,
        alignment=TA_CENTER,
        textColor=colors.HexColor('#2E7D32')
    )
    
    heading_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        spaceBefore=20,
        spaceAfter=10,
        textColor=colors.HexColor('#1565C0')
    )
    
    content = []
    
    content.append(Paragraph("Crop Yield Prediction Report", title_style))
    content.append(Spacer(1, 12))
    
    report_date = datetime.now().strftime('%B %d, %Y at %H:%M')
    content.append(Paragraph(f"Generated on: {report_date}", styles['Normal']))
    content.append(Spacer(1, 20))
    
    content.append(Paragraph("Crop Information", heading_style))
    crop_data = [
        ['Crop Type', prediction_data.get('crop_type', 'N/A')],
        ['Predicted Yield', f"{prediction_data.get('predicted_yield', 0):.2f} tonnes/hectare"]
    ]
    crop_table = Table(crop_data, colWidths=[2*inch, 3*inch])
    crop_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#E8F5E9')),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 11),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 10),
        ('TOPPADDING', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#BDBDBD'))
    ]))
    content.append(crop_table)
    content.append(Spacer(1, 20))
    
    content.append(Paragraph("Soil Parameters", heading_style))
    soil_data = [
        ['Parameter', 'Value', 'Unit'],
        ['Soil pH', f"{prediction_data.get('soil_ph', 0):.2f}", '-'],
        ['Nitrogen (N)', f"{prediction_data.get('nitrogen', 0):.2f}", 'kg/ha'],
        ['Phosphorus (P)', f"{prediction_data.get('phosphorus', 0):.2f}", 'kg/ha'],
        ['Potassium (K)', f"{prediction_data.get('potassium', 0):.2f}", 'kg/ha'],
        ['Organic Carbon', f"{prediction_data.get('organic_carbon', 0):.2f}", '%'],
        ['Soil Moisture', f"{prediction_data.get('soil_moisture', 0):.2f}", '%']
    ]
    soil_table = Table(soil_data, colWidths=[2*inch, 1.5*inch, 1.5*inch])
    soil_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1565C0')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#E3F2FD')),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#BDBDBD'))
    ]))
    content.append(soil_table)
    content.append(Spacer(1, 20))
    
    content.append(Paragraph("Climate Parameters", heading_style))
    climate_data = [
        ['Parameter', 'Value', 'Unit'],
        ['Temperature', f"{prediction_data.get('temperature', 0):.2f}", '°C'],
        ['Rainfall', f"{prediction_data.get('rainfall', 0):.2f}", 'mm'],
        ['Humidity', f"{prediction_data.get('humidity', 0):.2f}", '%'],
        ['Solar Radiation', f"{prediction_data.get('solar_radiation', 0):.2f}", 'MJ/m²/day'],
        ['Wind Speed', f"{prediction_data.get('wind_speed', 0):.2f}", 'km/h']
    ]
    climate_table = Table(climate_data, colWidths=[2*inch, 1.5*inch, 1.5*inch])
    climate_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#FF8F00')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('TOPPADDING', (0, 0), (-1, -1), 8),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#FFF3E0')),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#BDBDBD'))
    ]))
    content.append(climate_table)
    content.append(Spacer(1, 30))
    
    content.append(Paragraph("Disclaimer", heading_style))
    disclaimer_text = """This prediction is based on a machine learning model trained on synthetic agricultural data. 
    The actual crop yield may vary based on various factors not captured in this model, including pest infestations, 
    disease outbreaks, farming practices, and localized weather variations. This report should be used as a guide 
    and not as a definitive forecast."""
    content.append(Paragraph(disclaimer_text, styles['Normal']))
    
    doc.build(content)
    
    return filename, filepath

def generate_text_report(prediction_data):
    report = []
    report.append("=" * 60)
    report.append("       CROP YIELD PREDICTION REPORT")
    report.append("=" * 60)
    report.append("")
    report.append(f"Generated on: {datetime.now().strftime('%B %d, %Y at %H:%M')}")
    report.append("")
    report.append("-" * 60)
    report.append("PREDICTION RESULTS")
    report.append("-" * 60)
    report.append(f"Crop Type: {prediction_data.get('crop_type', 'N/A')}")
    report.append(f"Predicted Yield: {prediction_data.get('predicted_yield', 0):.2f} tonnes/hectare")
    report.append("")
    report.append("-" * 60)
    report.append("SOIL PARAMETERS")
    report.append("-" * 60)
    report.append(f"Soil pH: {prediction_data.get('soil_ph', 0):.2f}")
    report.append(f"Nitrogen (N): {prediction_data.get('nitrogen', 0):.2f} kg/ha")
    report.append(f"Phosphorus (P): {prediction_data.get('phosphorus', 0):.2f} kg/ha")
    report.append(f"Potassium (K): {prediction_data.get('potassium', 0):.2f} kg/ha")
    report.append(f"Organic Carbon: {prediction_data.get('organic_carbon', 0):.2f} %")
    report.append(f"Soil Moisture: {prediction_data.get('soil_moisture', 0):.2f} %")
    report.append("")
    report.append("-" * 60)
    report.append("CLIMATE PARAMETERS")
    report.append("-" * 60)
    report.append(f"Temperature: {prediction_data.get('temperature', 0):.2f} °C")
    report.append(f"Rainfall: {prediction_data.get('rainfall', 0):.2f} mm")
    report.append(f"Humidity: {prediction_data.get('humidity', 0):.2f} %")
    report.append(f"Solar Radiation: {prediction_data.get('solar_radiation', 0):.2f} MJ/m²/day")
    report.append(f"Wind Speed: {prediction_data.get('wind_speed', 0):.2f} km/h")
    report.append("")
    report.append("=" * 60)
    
    return "\n".join(report)
