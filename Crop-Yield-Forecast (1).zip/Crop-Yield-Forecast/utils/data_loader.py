import numpy as np
import pandas as pd

def generate_synthetic_dataset(n_samples=1000):
    np.random.seed(42)
    
    crop_types = ['Paddy', 'Wheat', 'Maize', 'Cotton', 'Sugarcane']
    
    data = {
        'crop_type': np.random.choice(crop_types, n_samples),
        'soil_ph': np.random.uniform(4.5, 8.5, n_samples),
        'nitrogen': np.random.uniform(100, 300, n_samples),
        'phosphorus': np.random.uniform(10, 80, n_samples),
        'potassium': np.random.uniform(100, 400, n_samples),
        'organic_carbon': np.random.uniform(0.2, 2.5, n_samples),
        'soil_moisture': np.random.uniform(20, 80, n_samples),
        'temperature': np.random.uniform(15, 40, n_samples),
        'rainfall': np.random.uniform(500, 2500, n_samples),
        'humidity': np.random.uniform(40, 95, n_samples),
        'solar_radiation': np.random.uniform(10, 30, n_samples),
        'wind_speed': np.random.uniform(2, 20, n_samples)
    }
    
    df = pd.DataFrame(data)
    
    crop_base_yield = {
        'Paddy': 4.5,
        'Wheat': 3.5,
        'Maize': 5.0,
        'Cotton': 2.0,
        'Sugarcane': 70.0
    }
    
    yield_values = []
    for idx, row in df.iterrows():
        base = crop_base_yield[row['crop_type']]
        
        ph_factor = 1 - abs(row['soil_ph'] - 6.5) * 0.05
        n_factor = min(row['nitrogen'] / 200, 1.2)
        p_factor = min(row['phosphorus'] / 50, 1.1)
        k_factor = min(row['potassium'] / 250, 1.1)
        oc_factor = min(row['organic_carbon'] / 1.5, 1.2)
        moisture_factor = 1 - abs(row['soil_moisture'] - 50) * 0.005
        temp_factor = 1 - abs(row['temperature'] - 25) * 0.02
        rain_factor = min(row['rainfall'] / 1500, 1.2)
        humidity_factor = 1 - abs(row['humidity'] - 70) * 0.003
        solar_factor = min(row['solar_radiation'] / 20, 1.1)
        wind_factor = 1 - (row['wind_speed'] - 5) * 0.01 if row['wind_speed'] > 5 else 1
        
        combined_factor = (ph_factor * n_factor * p_factor * k_factor * 
                          oc_factor * moisture_factor * temp_factor * 
                          rain_factor * humidity_factor * solar_factor * wind_factor)
        
        noise = np.random.uniform(0.9, 1.1)
        yield_val = base * combined_factor * noise
        yield_val = max(yield_val, base * 0.3)
        yield_values.append(round(yield_val, 2))
    
    df['yield_per_hectare'] = yield_values
    
    return df

def load_dataset():
    return generate_synthetic_dataset()

def get_feature_columns():
    return ['soil_ph', 'nitrogen', 'phosphorus', 'potassium', 'organic_carbon',
            'soil_moisture', 'temperature', 'rainfall', 'humidity', 
            'solar_radiation', 'wind_speed']

def get_crop_types():
    return ['Paddy', 'Wheat', 'Maize', 'Cotton', 'Sugarcane']

def get_dataset_stats():
    df = load_dataset()
    feature_cols = get_feature_columns()
    stats = {}
    for col in feature_cols:
        stats[col] = {
            'mean': round(df[col].mean(), 2),
            'min': round(df[col].min(), 2),
            'max': round(df[col].max(), 2)
        }
    return stats
