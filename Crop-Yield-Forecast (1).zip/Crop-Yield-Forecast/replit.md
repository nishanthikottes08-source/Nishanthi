# Soil-Climate Integrated Crop Yield Forecasting Model

## Overview
A Flask-based machine learning web application that predicts crop yield based on integrated soil and climate features. The model uses Random Forest regression trained on synthetic agricultural data. Includes a Tamil-English bilingual AI chatbot for agricultural guidance.

## Project Structure
```
├── app.py                    # Main Flask application
├── train_model.py           # Model training script
├── predict.py               # Prediction module
├── preprocessing.py         # Data preprocessing with StandardScaler
├── requirements.txt         # Python dependencies
├── model/
│   ├── crop_yield_model.pkl # Trained Random Forest model
│   └── preprocessor.pkl     # Fitted StandardScaler and LabelEncoder
├── utils/
│   ├── data_loader.py       # Synthetic dataset generation
│   ├── report_generator.py  # PDF report generation
│   └── chatbot.py           # Tamil-English bilingual AI chatbot
├── templates/
│   ├── index.html           # Input form page
│   ├── result.html          # Prediction results page
│   └── chat.html            # Chatbot interface
└── static/
    ├── style.css            # Application styling
    ├── feature_importance.png
    └── comparison_chart.png
```

## Features
- **11 Input Parameters**: Soil pH, N, P, K, Organic Carbon, Moisture + Temperature, Rainfall, Humidity, Solar Radiation, Wind Speed
- **5 Crop Types**: Paddy, Wheat, Maize, Cotton, Sugarcane
- **Random Forest Model**: Trained with 100 estimators
- **PDF Reports**: Downloadable prediction reports via ReportLab
- **Visualization**: Feature comparison charts
- **AI Chatbot**: Tamil-English bilingual chatbot for agricultural questions (powered by OpenAI GPT-5)

## Running the Application
```bash
python app.py
```
The app runs on port 5000.

## API Endpoints
- `GET /` - Input form (Crop Prediction)
- `POST /predict` - Generate prediction
- `POST /download_report` - Download PDF report
- `GET /chat` - Chatbot interface
- `POST /chat/send` - Send message to chatbot

## Environment Variables
- `OPENAI_API_KEY` - Required for chatbot functionality
- `SESSION_SECRET` - Flask session secret

## Recent Changes
- Initial project creation (December 2025)
- Implemented complete ML pipeline with preprocessing
- Added PDF report generation
- Created responsive UI with comparison charts
- Added Tamil-English bilingual AI chatbot (December 2025)
